#!/bin/sh
python2 baseline.py $@
