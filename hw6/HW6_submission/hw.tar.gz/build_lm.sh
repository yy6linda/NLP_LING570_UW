#!/bin/sh
python3 build_lm.py $@
