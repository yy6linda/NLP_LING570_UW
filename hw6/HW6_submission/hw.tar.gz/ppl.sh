#!/bin/sh
python3 ppl.py $@
