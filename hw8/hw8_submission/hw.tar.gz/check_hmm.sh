#!/bin/sh
python3 check_hmm.py $@
