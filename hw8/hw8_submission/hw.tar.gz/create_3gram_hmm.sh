#!/bin/sh
python3 create_3gram_hmm.py $@
