#!/bin/sh
python3 create_2gram_hmm.py $@
