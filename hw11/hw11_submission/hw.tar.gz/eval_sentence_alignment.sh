#!/bin/sh
python3 eval_sentence_alignment.py $@
