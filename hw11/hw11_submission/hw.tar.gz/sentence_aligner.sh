#!/bin/sh
python3 sentence_aligner.py $@
